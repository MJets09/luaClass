Orange = Object.extend(Object)


function love.load()
  
myOrange = love.graphics.newImage("rsc/orange.png")
  
end

math.randomseed(os.time())

--Orange constructor -- used to create a new Orange
function Orange:new(img,x,y)
    self.myImage = myImage
    self.x = x
    self.y = y
end

function Orange:update(dt)
  
  
end

function Orange:draw()
    love.graphics.draw(self.myImage, self.x, self.y)
end