function love.load()
  Object = require "classic"
  require "orange"
  
  crate = love.graphics.newImage("rsc/crate.png")
  orange = love.graphics.newImage("rsc/orange.png")
  
  crX = 400
  crY = 500
  
  --Create a Orange image that shows up randomly
  o1 = Orange(orange, math.random(1,300),math.random(1,300))
end


function love.update(dt)
  
 --Crate movement
 if love.keyboard.isDown("right") then
    crX = crX + 5
    if crX > love.graphics.getWidth() - 100 then
      
       crX = 700
       
    end
    
  elseif love.keyboard.isDown("left") then
    
    crX = crX - 5

    if crX < 0 then
      
       crX = 0
       
    end
  end
  
end



function love.draw()
  
  love.graphics.draw(crate, crX,crY)
  
  --Uses the orange draw function in the orange class
  
  o1:draw()
end
